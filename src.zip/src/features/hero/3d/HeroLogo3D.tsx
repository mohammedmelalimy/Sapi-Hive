'use client';

import { useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import Image from 'next/image';
import icon from '../assets/sapihive-brand-icon.png';
import { logoPaths } from './logoPaths';

import type { HeroLogoMotion } from './heroLogoMotion';

/** Keep the exact contour of each disconnected piece of the approved logo. */
function makeShape(vertices: ReadonlyArray<readonly [number, number]>) {
  const shape = new THREE.Shape();
  const first = vertices[0];
  const last = vertices[vertices.length - 1];
  shape.moveTo((first[0] + last[0]) / 2, (first[1] + last[1]) / 2);
  for (let n = 0; n < vertices.length; n += 1) {
    const point = vertices[n];
    const next = vertices[(n + 1) % vertices.length];
    shape.quadraticCurveTo(point[0], point[1], (point[0] + next[0]) / 2, (point[1] + next[1]) / 2);
  }
  shape.closePath();
  return shape;
}

const WHITE = new THREE.Color('#F5F7FA');
const AMBER = new THREE.Color('#F2A900');
const GLOW = new THREE.Color('#F2A900');

function BrandSculpture({ motion }: { motion: HeroLogoMotion }) {
  const root = useRef<THREE.Group>(null);
  const pieces = useRef<Array<THREE.Group | null>>([]);
  const { size } = useThree();

  const geometries = useMemo(() => logoPaths.map(part => new THREE.ExtrudeGeometry(
    makeShape(part.points as unknown as ReadonlyArray<readonly [number, number]>),
    { depth: 0.22, steps: 1, bevelEnabled: true, bevelThickness: 0.045, bevelSize: 0.04, bevelSegments: 3, curveSegments: 6 },
  )), []);

  const materials = useMemo(() => logoPaths.map(part => new THREE.MeshStandardMaterial({
    color: part.amber ? AMBER : WHITE,
    roughness: 0.33,
    metalness: 0.12,
    transparent: true,
    opacity: 0,
    emissive: part.amber ? GLOW : new THREE.Color('#162A3E'),
    emissiveIntensity: part.amber ? 0.17 : 0.035,
  })), []);

  useEffect(() => () => {
    geometries.forEach(geometry => geometry.dispose());
    materials.forEach(material => material.dispose());
  }, [geometries, materials]);

  useFrame(({ camera, clock }, delta) => {
    const main = root.current;
    if (!main) return;

    const mobile = size.width < 768;
    const assembly = THREE.MathUtils.clamp(motion.assembly, 0, 1);
    const depth = THREE.MathUtils.clamp(motion.depth, 0, 1);
    const focused = THREE.MathUtils.clamp(motion.focusMode, 0, 1);
    const final = THREE.MathUtils.clamp(motion.final, 0, 1);
    const exit = THREE.MathUtils.clamp(motion.exit, 0, 1);
    const scaleBase = mobile ? Math.min(0.62, size.width / 650) : Math.min(1.0, size.width / 1550 + 0.15);
    const scale = scaleBase * (1 - final * 0.31) * (1 - focused * (mobile ? 0.02 : 0.12));
    const amp = THREE.MathUtils.damp(main.scale.x, scale, 8, delta);
    main.scale.setScalar(amp);

    // Services: model moves left on desktop to reserve an independent text column.
    // On mobile: model rises, while the text is below it in document order visually.
    const targetX = mobile ? 0 : -1.75 * focused;
    const targetY = (mobile ? 0.72 * focused : 0.15 * focused) + 1.38 * final;
    main.position.x = THREE.MathUtils.damp(main.position.x, targetX, 8, delta);
    main.position.y = THREE.MathUtils.damp(main.position.y, targetY, 8, delta);
    main.rotation.x = THREE.MathUtils.damp(main.rotation.x, -0.30 * depth * (1 - final), 7, delta);
    main.rotation.y = THREE.MathUtils.damp(main.rotation.y,
      (0.24 * depth + 0.10 * Math.sin(clock.elapsedTime * 0.55) * depth) * (1 - final), 7, delta);
    main.rotation.z = THREE.MathUtils.damp(main.rotation.z, 0.06 * depth * (1 - final), 7, delta);

    // Actual camera dolly and slight lateral movement; not just a rotated PNG plane.
    camera.position.x = THREE.MathUtils.damp(camera.position.x, depth * 0.32 * (1 - final), 5, delta);
    camera.position.y = THREE.MathUtils.damp(camera.position.y, 0.15 * depth * (1 - final), 5, delta);
    camera.position.z = THREE.MathUtils.damp(camera.position.z, 13 - depth * 1.0, 5, delta);
    camera.lookAt(0, 0, 0);

    logoPaths.forEach((part, index) => {
      const group = pieces.current[index];
      if (!group) return;
      const theta = index * 2.3999632; // deterministic golden-angle scatter
      const dx = Math.cos(theta) * (1.9 + index % 3 * 0.5);
      const dy = Math.sin(theta) * (1.7 + index % 4 * 0.37);
      const dz = 1.2 + (index % 4) * 0.68;
      const targetX = dx * (1 - assembly);
      const targetY = dy * (1 - assembly);
      const targetZ = dz * (1 - assembly);
      group.position.set(targetX, targetY, targetZ);
      group.rotation.set((1 - assembly) * (index % 2 ? -0.9 : 0.8), (1 - assembly) * (index % 3 - 1) * 1.1, (1 - assembly) * 1.1);
      group.scale.setScalar(0.72 + assembly * 0.28);

      const mat = materials[index];
      const highlighted = !part.amber && focused > 0.1 && part.serviceGroup === Math.round(motion.focus);
      mat.color.lerpColors(part.amber ? AMBER : WHITE, AMBER, highlighted ? Math.min(1, focused * 0.88) : 0);
      mat.emissiveIntensity = highlighted ? 0.37 : part.amber ? 0.18 : 0.035;
      mat.opacity = Math.min(1, Math.max(0, assembly * 2.8 - 0.18)) * (1 - exit);
    });
  });

  return (
    <>
      <ambientLight intensity={1.35} />
      <directionalLight position={[3, 5, 7]} intensity={2.4} color="#F6F9FC" />
      <directionalLight position={[-4, -2, 3]} intensity={1.35} color="#9EC0D7" />
      <pointLight position={[1.8, -1.1, 2]} intensity={2.1} distance={9} color="#F2A900" />
      <group ref={root}>
        {logoPaths.map((part, i) => (
          <group key={i} ref={(node) => { pieces.current[i] = node; }}>
            <mesh geometry={geometries[i]} material={materials[i]} castShadow receiveShadow />
          </group>
        ))}
      </group>
    </>
  );
}

export default function HeroLogo3D({ motion }: { motion: HeroLogoMotion }) {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full">
      <Canvas
        dpr={[1, 1.6]}
        camera={{ position: [0, 0, 13], fov: 35, near: 0.1, far: 50 }}
        gl={{ alpha: true, antialias: true, powerPreference: 'high-performance' }}
        fallback={<div className="grid h-full w-full place-items-center"><Image src={icon} alt="" className="h-48 w-48 object-contain" /></div>}
      >
        <BrandSculpture motion={motion} />
      </Canvas>
    </div>
  );
}
